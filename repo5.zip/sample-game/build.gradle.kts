plugins {
    java
}
