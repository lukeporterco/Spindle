plugins {
    `java-library`
}
